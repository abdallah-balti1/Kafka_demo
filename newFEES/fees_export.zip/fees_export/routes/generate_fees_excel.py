from flask import Blueprint
from flask_restful import Api

from resources.generate_fees_excel import GenerateFeesExcelResource

GENERATE_FEES_EXCEL_BLUEPRINT = Blueprint("generate_fees_excel", __name__)

Api(GENERATE_FEES_EXCEL_BLUEPRINT).add_resource(
    GenerateFeesExcelResource, "/generate_fees_excel", endpoint="generate_fees_excel"
)

# À enregistrer comme les autres blueprints, ex. dans app.py :
#   from routes.generate_fees_excel import GENERATE_FEES_EXCEL_BLUEPRINT
#   app.register_blueprint(GENERATE_FEES_EXCEL_BLUEPRINT, url_prefix="/api")
