"""
Génère le fichier Excel de fees à partir des lignes de données déjà
enrichies (résultat de RetrieveFeesDataResource : ADL in/out +
FeeExportService.build_fee_columns mergés dans chaque ligne).

Mise en page pilotée par constants/excel_layout_config.py (EXCEL_SECTIONS,
BASE_COLUMNS) : ajouter une section ou une colonne ne demande aucune
modification de ce fichier.

Gotchas openpyxl respectés (cf. skill xlsx) :
  - cellules fusionnées : on n'écrit que sur l'ancre top-left
  - pas de valeurs hardcodées de type "total" ici (pas de formules dans ce
    template, donc pas de recalcul LibreOffice nécessaire)
"""

from io import BytesIO

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from constants.excel_layout_config import BASE_COLUMNS, COLOR_BASE, EXCEL_SECTIONS

HEADER_FONT = Font(name="Arial", size=9, bold=True, color="FFFFFF")
BASE_HEADER_FONT = Font(name="Arial", size=9, bold=True, color="000000")
DATA_FONT = Font(name="Arial", size=8)
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)

SECTION_TITLE_ROW = 1
SUBSECTION_TITLE_ROW = 2
COLUMN_LABEL_ROW = 3
DATA_START_ROW = 4


class FeeExcelGenerator:

    @classmethod
    def generate(cls, rows: list[dict]) -> BytesIO:
        wb = Workbook()
        ws = wb.active
        ws.title = "Fees Review"

        col_index = cls._write_headers(ws)
        cls._write_data(ws, rows, col_index)
        cls._apply_column_widths(ws, col_index)

        ws.freeze_panes = f"A{DATA_START_ROW}"

        buffer = BytesIO()
        wb.save(buffer)
        buffer.seek(0)
        return buffer

    @staticmethod
    def _write_headers(ws) -> list[str]:
        """
        Écrit les 3 lignes d'en-tête et retourne col_index : la liste
        ordonnée des clés de données, une par colonne (même ordre que les
        colonnes écrites), pour que _write_data sache quoi lire.
        """
        col_index: list[str] = []
        col = 1

        # --- Colonnes de base (identification produit) : fusion verticale sur 3 lignes ---
        for label, data_key in BASE_COLUMNS:
            ws.merge_cells(
                start_row=SECTION_TITLE_ROW, start_column=col,
                end_row=COLUMN_LABEL_ROW, end_column=col,
            )
            cell = ws.cell(row=SECTION_TITLE_ROW, column=col, value=label)
            cell.font = BASE_HEADER_FONT
            cell.alignment = CENTER
            cell.fill = PatternFill("solid", fgColor=COLOR_BASE)
            col_index.append(data_key)
            col += 1

        # --- Sections de fees ---
        for section in EXCEL_SECTIONS:
            section_start_col = col
            fill = PatternFill("solid", fgColor=section["color"])

            for subsection in section["subsections"]:
                subsection_start_col = col
                for label, data_key in subsection["columns"]:
                    cell = ws.cell(row=COLUMN_LABEL_ROW, column=col, value=label)
                    cell.font = HEADER_FONT
                    cell.alignment = CENTER
                    cell.fill = fill
                    col_index.append(data_key)
                    col += 1

                # Fusion du titre de sous-section sur ses colonnes
                if col - 1 > subsection_start_col:
                    ws.merge_cells(
                        start_row=SUBSECTION_TITLE_ROW, start_column=subsection_start_col,
                        end_row=SUBSECTION_TITLE_ROW, end_column=col - 1,
                    )
                sub_cell = ws.cell(
                    row=SUBSECTION_TITLE_ROW, column=subsection_start_col,
                    value=subsection["subtitle"],
                )
                sub_cell.font = HEADER_FONT
                sub_cell.alignment = CENTER
                sub_cell.fill = fill

            # Fusion du titre de section sur toutes ses colonnes
            if col - 1 > section_start_col:
                ws.merge_cells(
                    start_row=SECTION_TITLE_ROW, start_column=section_start_col,
                    end_row=SECTION_TITLE_ROW, end_column=col - 1,
                )
            title_cell = ws.cell(
                row=SECTION_TITLE_ROW, column=section_start_col, value=section["title"]
            )
            title_cell.font = HEADER_FONT
            title_cell.alignment = CENTER
            title_cell.fill = fill

        return col_index

    @staticmethod
    def _write_data(ws, rows: list[dict], col_index: list[str]) -> None:
        for row_offset, row_data in enumerate(rows):
            excel_row = DATA_START_ROW + row_offset
            for col_offset, data_key in enumerate(col_index, start=1):
                cell = ws.cell(
                    row=excel_row, column=col_offset, value=row_data.get(data_key)
                )
                cell.font = DATA_FONT

    @staticmethod
    def _apply_column_widths(ws, col_index: list[str]) -> None:
        for i in range(1, len(col_index) + 1):
            ws.column_dimensions[get_column_letter(i)].width = 16
