# -----------------------------------------------------------------------------
# À AJOUTER dans src/client/smartgps.py, à côté de get_adl_fees_data
# (même fichier, même pattern). Ne remplace rien d'existant.
# -----------------------------------------------------------------------------

def get_fees_data(product_ids):
    """Calls /retrieve_fees_data for given product_ids — renvoie TOUTES
    les fees (Management/Distribution/Charity/Advisory/Subscription/
    Redemption/Conversion/Specific & External), labels déjà traduits.

    Ne concerne PAS l'ADL in/out : reste sur get_adl_fees_data /
    /retrieve_adl_fees_data existant, inchangé.
    """
    logging.debug("[SMARTGPS] Fees data loading...")
    session = get_new_requests_session()
    url = "{}/retrieve_fees_data".format(config.SMARTGPS_URL)

    headers = {"Api-Key": config.API_KEY}
    data = {"prod_cd_list": product_ids}

    response = session.post(url, json=data, headers=headers, verify=False)
    handle_http_error(response)
    logging.debug("[SMARTGPS] Fees data loaded.")

    return response.json()
