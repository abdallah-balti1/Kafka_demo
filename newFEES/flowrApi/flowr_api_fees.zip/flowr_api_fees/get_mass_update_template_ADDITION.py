# -----------------------------------------------------------------------------
# À AJOUTER dans src/util/mass_update/get_mass_update_template.py, dans la
# fonction retrieve_mass_update_template(task, product_ids=[]) — JUSTE APRÈS
# le bloc existant "if "Specific Fees template" in task.name: ... return wb"
# (donc AVANT la partie "Retrieve COS template file" générique).
#
# ⚠️ ATTENTION À L'ORDRE DES CONDITIONS : "Specific Fees template" contient
# la sous-chaîne "Fees template". Si ce nouveau bloc était testé AVANT le
# bloc ADL existant, ou si on utilisait un nom de tâche qui matche par
# accident, on casserait le flux ADL. Solution : nom de tâche distinct
# ("All Fees template", PAS "Fees template" tout court) + ce bloc doit
# rester un `elif` (ou un `if` placé APRÈS le bloc ADL, jamais avant).
#
# Imports à ajouter en haut du fichier :
#   from client.smartgps import get_fees_data
#   from util.mass_update.fees_template import create_fees_template_workbook
# -----------------------------------------------------------------------------

    # ==================================================================
    # GENERALIZED CASE: Upload All Fees template (tous types de fees,
    # hors ADL in/out qui reste géré par le bloc "Specific Fees template"
    # ci-dessus, inchangé)
    # ==================================================================
    elif "All Fees template" in task.name:
        with SessionCriticalActionManager(
            "Getting fees data from smartgps",
            db.session,
            DEV_TEAM_EMAILS,
        ):
            # get_fees_data(product_ids) appelle /retrieve_fees_data côté
            # cosmos_api et renvoie déjà les données prêtes à parser
            payload = get_fees_data(product_ids)

            # Payload peut être :
            # - une liste directe
            # - ou { "SIN": [...], "SUB": [...], "unknown": [...] }
            if isinstance(payload, dict):
                fees_data = (payload.get("SUB") or []) + (payload.get("SIN") or [])
            else:
                fees_data = payload or []

            wb = create_fees_template_workbook(fees_data)
            return wb
