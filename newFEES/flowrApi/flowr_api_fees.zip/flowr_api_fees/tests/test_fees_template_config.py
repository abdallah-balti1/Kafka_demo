"""
Test de cohérence structurelle de constants/fees_template.py (structure
à 3 niveaux : section / sous-section / colonne), sans DB, sans Flask.

Lancer avec :
    python tests/test_fees_template_config.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from constants.fees_template import (  # noqa: E402
    BASE_COLUMNS,
    COL_WIDTHS,
    COSMOS_ID_COLUMN_INDEX,
    EDITABLE_COLUMNS,
    HEADERS,
    KEYS,
    N_BASE_COLUMNS,
    NUMERIC_EDITABLE_COLUMNS,
    SECTION_GROUPS,
    SECTIONS,
    SUBSECTION_GROUPS,
    TEXT_EDITABLE_COLUMNS,
    TOTAL_COLUMNS,
)


def test_headers_and_keys_same_length():
    assert len(HEADERS) == len(KEYS) == TOTAL_COLUMNS
    print(f"✅ test_headers_and_keys_same_length OK ({TOTAL_COLUMNS} colonnes)")


def test_no_duplicate_keys():
    duplicates = [k for k in KEYS if KEYS.count(k) > 1]
    assert not duplicates, f"Clés en double détectées : {set(duplicates)}"
    print("✅ test_no_duplicate_keys OK")


def test_no_adl_section():
    """Vérifie explicitement qu'aucune section ADL n'est présente."""
    titles = [s["title"] for s in SECTIONS]
    assert not any("ADL" in t for t in titles), (
        f"Une section ADL a été trouvée : {titles} — elle ne doit pas "
        "être dupliquée ici, déjà gérée par /retrieve_adl_fees_data"
    )
    assert not any("adl" in k.lower() for k in KEYS), (
        "Une clé ADL a été trouvée dans KEYS, ne devrait pas exister ici"
    )
    print("✅ test_no_adl_section OK (aucune section/clé ADL trouvée)")


def test_section_groups_cover_fee_columns_contiguously():
    """SECTION_GROUPS doit couvrir exactement les colonnes de fees
    (après les colonnes de base), sans trou ni chevauchement."""
    covered = []
    for start, end, _title, _color in SECTION_GROUPS:
        covered.extend(range(start, end + 1))
    expected = list(range(N_BASE_COLUMNS + 1, TOTAL_COLUMNS + 1))
    assert covered == expected, (
        "SECTION_GROUPS ne couvre pas exactement les colonnes de fees "
        f"attendues.\nCouvert: {covered[:10]}...\nAttendu: {expected[:10]}..."
    )
    print("✅ test_section_groups_cover_fee_columns_contiguously OK")


def test_subsection_groups_nested_in_section_groups():
    """Chaque sous-section doit être entièrement contenue dans sa section."""
    for sub_start, sub_end, _sub_title, sub_color in SUBSECTION_GROUPS:
        matching_section = next(
            (s for s in SECTION_GROUPS if s[0] <= sub_start and sub_end <= s[1]),
            None,
        )
        assert matching_section is not None, (
            f"Sous-section [{sub_start}-{sub_end}] non contenue dans une section"
        )
        assert matching_section[3] == sub_color, (
            "La couleur de la sous-section doit matcher celle de sa section parente"
        )
    print("✅ test_subsection_groups_nested_in_section_groups OK")


def test_editable_columns_are_fee_columns_only():
    base_col_indices = set(range(1, N_BASE_COLUMNS + 1))
    assert not (base_col_indices & set(EDITABLE_COLUMNS)), (
        "Une colonne d'identification est marquée comme éditable"
    )
    expected_editable_count = sum(
        len(sub["columns"]) for s in SECTIONS for sub in s["subsections"]
    )
    assert len(EDITABLE_COLUMNS) == expected_editable_count, (
        f"Attendu {expected_editable_count} colonnes éditables, "
        f"trouvé {len(EDITABLE_COLUMNS)}"
    )
    print(f"✅ test_editable_columns_are_fee_columns_only OK ({len(EDITABLE_COLUMNS)} colonnes éditables)")


def test_numeric_and_text_columns_partition_editable():
    assert set(NUMERIC_EDITABLE_COLUMNS) | set(TEXT_EDITABLE_COLUMNS) == set(EDITABLE_COLUMNS)
    assert not (set(NUMERIC_EDITABLE_COLUMNS) & set(TEXT_EDITABLE_COLUMNS))
    print(
        f"✅ test_numeric_and_text_columns_partition_editable OK "
        f"({len(NUMERIC_EDITABLE_COLUMNS)} numériques, {len(TEXT_EDITABLE_COLUMNS)} texte)"
    )


def test_cosmos_id_not_editable_and_correctly_indexed():
    assert COSMOS_ID_COLUMN_INDEX == 1
    assert COSMOS_ID_COLUMN_INDEX not in EDITABLE_COLUMNS
    assert HEADERS[COSMOS_ID_COLUMN_INDEX - 1] == "Cosmos ID"
    print("✅ test_cosmos_id_not_editable_and_correctly_indexed OK")


def test_col_widths_defined_for_every_column():
    missing = [i for i in range(1, TOTAL_COLUMNS + 1) if i not in COL_WIDTHS]
    assert not missing, f"COL_WIDTHS manquant pour les colonnes : {missing}"
    print("✅ test_col_widths_defined_for_every_column OK")


if __name__ == "__main__":
    test_headers_and_keys_same_length()
    test_no_duplicate_keys()
    test_no_adl_section()
    test_section_groups_cover_fee_columns_contiguously()
    test_subsection_groups_nested_in_section_groups()
    test_editable_columns_are_fee_columns_only()
    test_numeric_and_text_columns_partition_editable()
    test_cosmos_id_not_editable_and_correctly_indexed()
    test_col_widths_defined_for_every_column()
    print(f"\n🎉 Tous les tests passent. Config prête : {TOTAL_COLUMNS} colonnes au total.")
