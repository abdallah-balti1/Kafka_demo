"""
Test de la logique de dispatch par nom de tâche — vérifie qu'il n'y a
PAS de collision entre "Specific Fees template" (ADL, existant) et
"All Fees template" (nouveau), et que le payload SIN/SUB est bien
fusionné dans le bon ordre.

Lancer avec :
    python tests/test_task_name_dispatch.py
"""


def resolve_branch(task_name: str) -> str:
    """Reproduit la logique de dispatch attendue dans
    retrieve_mass_update_template, sans dépendances Flask/DB."""
    if "Specific Fees template" in task_name:
        return "ADL_BRANCH"
    elif "All Fees template" in task_name:
        return "ALL_FEES_BRANCH"
    else:
        return "GENERIC_COS_BRANCH"


def test_specific_fees_template_still_routes_to_adl():
    assert resolve_branch("Specific Fees template") == "ADL_BRANCH"
    print("✅ test_specific_fees_template_still_routes_to_adl OK")


def test_all_fees_template_routes_to_new_branch():
    assert resolve_branch("All Fees template") == "ALL_FEES_BRANCH"
    print("✅ test_all_fees_template_routes_to_new_branch OK")


def test_no_collision_between_the_two_task_names():
    """LE test qui compte : si on avait nommé la nouvelle tâche
    "Fees template" tout court, ce test aurait échoué car
    "Specific Fees template" contient "Fees template" comme sous-chaîne."""
    specific_name = "Specific Fees template"
    assert "Fees template" in specific_name  # confirme le risque de collision
    assert resolve_branch(specific_name) == "ADL_BRANCH", (
        "COLLISION DÉTECTÉE : une tâche ADL route vers la mauvaise branche"
    )
    print("✅ test_no_collision_between_the_two_task_names OK (collision évitée)")


def test_other_task_names_fall_through_to_generic():
    assert resolve_branch("Some other mass update") == "GENERIC_COS_BRANCH"
    print("✅ test_other_task_names_fall_through_to_generic OK")


def merge_sin_sub_payload(payload) -> list:
    if isinstance(payload, dict):
        return (payload.get("SUB") or []) + (payload.get("SIN") or [])
    return payload or []


def test_merge_payload_dict_form():
    payload = {"SIN": [{"a": 1}], "SUB": [{"b": 2}], "unknown": ["999"]}
    result = merge_sin_sub_payload(payload)
    assert result == [{"b": 2}, {"a": 1}], "SUB doit précéder SIN dans le merge"
    print("✅ test_merge_payload_dict_form OK")


def test_merge_payload_list_form():
    payload = [{"a": 1}, {"b": 2}]
    result = merge_sin_sub_payload(payload)
    assert result == payload
    print("✅ test_merge_payload_list_form OK")


def test_merge_payload_empty_or_none():
    assert merge_sin_sub_payload(None) == []
    assert merge_sin_sub_payload({}) == []
    assert merge_sin_sub_payload([]) == []
    print("✅ test_merge_payload_empty_or_none OK")


if __name__ == "__main__":
    test_specific_fees_template_still_routes_to_adl()
    test_all_fees_template_routes_to_new_branch()
    test_no_collision_between_the_two_task_names()
    test_other_task_names_fall_through_to_generic()
    test_merge_payload_dict_form()
    test_merge_payload_list_form()
    test_merge_payload_empty_or_none()
    print("\n🎉 Tous les tests passent.")
