"""
Test de cohérence structurelle de constants/fees_template.py — sans DB,
sans Flask. Vérifie que la génération automatique de HEADERS/KEYS/GROUPS
est cohérente avant même de toucher à openpyxl.

Lancer avec :
    python tests/test_fees_template_config.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from constants.fees_template import (  # noqa: E402
    BASE_COLUMNS,
    COL_WIDTHS,
    COSMOS_ID_COLUMN_INDEX,
    EDITABLE_COLUMNS,
    FEE_SECTIONS,
    GROUPS,
    HEADERS,
    KEYS,
    TOTAL_COLUMNS,
)


def test_headers_and_keys_same_length():
    assert len(HEADERS) == len(KEYS) == TOTAL_COLUMNS, (
        f"HEADERS ({len(HEADERS)}), KEYS ({len(KEYS)}) et TOTAL_COLUMNS "
        f"({TOTAL_COLUMNS}) doivent être égaux"
    )
    print(f"✅ test_headers_and_keys_same_length OK ({TOTAL_COLUMNS} colonnes)")


def test_no_duplicate_keys():
    """Deux colonnes ne doivent jamais pointer vers la même clé JSON
    (sauf le cas particulier attendu, s'il y en a un) — sinon le mapping
    colonne -> valeur devient ambigu."""
    duplicates = [k for k in KEYS if KEYS.count(k) > 1]
    assert not duplicates, f"Clés en double détectées : {set(duplicates)}"
    print("✅ test_no_duplicate_keys OK")


def test_groups_cover_all_columns_contiguously():
    """Vérifie que GROUPS couvre bien 1..TOTAL_COLUMNS sans trou ni chevauchement."""
    covered = []
    for start, end, _label in GROUPS:
        covered.extend(range(start, end + 1))
    assert covered == list(range(1, TOTAL_COLUMNS + 1)), (
        "GROUPS ne couvre pas exactement toutes les colonnes de façon "
        "contiguë — vérifie qu'aucune section n'a été oubliée ou dupliquée"
    )
    print("✅ test_groups_cover_all_columns_contiguously OK")


def test_editable_columns_are_fee_columns_only():
    """Aucune colonne de BASE_COLUMNS (identification) ne doit être éditable."""
    base_col_indices = set(range(1, len(BASE_COLUMNS) + 1))
    assert not (base_col_indices & set(EDITABLE_COLUMNS)), (
        "Une colonne d'identification est marquée comme éditable, ce qui "
        "ne devrait jamais arriver"
    )
    expected_editable_count = sum(len(s["columns"]) for s in FEE_SECTIONS)
    assert len(EDITABLE_COLUMNS) == expected_editable_count, (
        f"Attendu {expected_editable_count} colonnes éditables, "
        f"trouvé {len(EDITABLE_COLUMNS)}"
    )
    print(f"✅ test_editable_columns_are_fee_columns_only OK ({len(EDITABLE_COLUMNS)} colonnes éditables)")


def test_cosmos_id_not_editable_and_correctly_indexed():
    assert COSMOS_ID_COLUMN_INDEX == 1
    assert COSMOS_ID_COLUMN_INDEX not in EDITABLE_COLUMNS
    assert HEADERS[COSMOS_ID_COLUMN_INDEX - 1] == "Cosmos ID"
    print("✅ test_cosmos_id_not_editable_and_correctly_indexed OK")


def test_col_widths_defined_for_every_column():
    missing = [i for i in range(1, TOTAL_COLUMNS + 1) if i not in COL_WIDTHS]
    assert not missing, f"COL_WIDTHS manquant pour les colonnes : {missing}"
    print("✅ test_col_widths_defined_for_every_column OK")


if __name__ == "__main__":
    test_headers_and_keys_same_length()
    test_no_duplicate_keys()
    test_groups_cover_all_columns_contiguously()
    test_editable_columns_are_fee_columns_only()
    test_cosmos_id_not_editable_and_correctly_indexed()
    test_col_widths_defined_for_every_column()
    print(f"\n🎉 Tous les tests passent. Config prête : {TOTAL_COLUMNS} colonnes au total.")
