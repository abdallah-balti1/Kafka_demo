"""
Génération du template Excel "Fees" généralisé, sur le pattern exact de
util/mass_update/specific_fees_template.py (ADL in/out, déjà en prod) —
mêmes fonctions, mêmes noms, adaptées pour piloter toutes les colonnes
via constants/fees_template.py au lieu des constantes ADL codées en dur.

Ne remplace PAS specific_fees_template.py : nouveau fichier séparé, pour
ne prendre aucun risque de régression sur l'endpoint ADL existant.
"""

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Protection, Side
from openpyxl.utils import get_column_letter
from openpyxl.workbook import Workbook
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.protection import SheetProtection
from openpyxl.worksheet.worksheet import Worksheet
from typing import Dict, List

from constants.fees_template import (
    BLACK_FILL_COLOR,
    BORDER_COLOR,
    COL_WIDTHS,
    COSMOS_ID_COLUMN_INDEX,
    DARK_FILL_COLOR,
    DATA_START_ROW,
    DATA_VALIDATION_ERROR_MESSAGE,
    DATA_VALIDATION_ERROR_TITLE,
    EDIT_FILL_COLOR,
    EDITABLE_COLUMNS,
    FONT_NAME,
    FONT_SIZE,
    GROUP_ROW_HEIGHT,
    GROUPS,
    HEADER_ROW_HEIGHT,
    HEADERS,
    KEYS,
    NUMERIC_EDITABLE_COLUMNS,
    SHEET_NAME,
    TITLE_ROW_HEIGHT,
    TITLE_TEXT,
    TOTAL_COLUMNS,
)


def create_styles() -> Dict[str, object]:
    black_fill = PatternFill("solid", fgColor=BLACK_FILL_COLOR)
    dark_fill = PatternFill("solid", fgColor=DARK_FILL_COLOR)
    edit_fill = PatternFill("solid", fgColor=EDIT_FILL_COLOR)

    font_white_bold = Font(name=FONT_NAME, size=FONT_SIZE, bold=True, color="FFFFFF")
    font_black = Font(name=FONT_NAME, size=FONT_SIZE, color="000000")

    align_center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    align_left = Alignment(horizontal="left", vertical="center", wrap_text=True)

    thin = Side(style="thin", color=BORDER_COLOR)
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    return {
        "black_fill": black_fill,
        "dark_fill": dark_fill,
        "edit_fill": edit_fill,
        "font_white_bold": font_white_bold,
        "font_black": font_black,
        "align_center": align_center,
        "align_left": align_left,
        "border": border,
    }


def create_header_rows(ws: Worksheet, styles: Dict[str, object]) -> None:
    # Ligne 1 : titre
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=TOTAL_COLUMNS)
    c = ws.cell(row=1, column=1, value=TITLE_TEXT)
    c.fill = styles["black_fill"]
    c.font = styles["font_white_bold"]
    c.alignment = styles["align_left"]
    c.border = styles["border"]
    ws.row_dimensions[1].height = TITLE_ROW_HEIGHT

    # Ligne 2 : groupes (sections)
    for start_col, end_col, label in GROUPS:
        ws.merge_cells(start_row=2, start_column=start_col, end_row=2, end_column=end_col)
        cell = ws.cell(row=2, column=start_col, value=label)
        cell.fill = styles["dark_fill"]
        cell.font = styles["font_white_bold"]
        cell.alignment = styles["align_center"]
        for col in range(start_col, end_col + 1):
            cc = ws.cell(row=2, column=col)
            cc.border = styles["border"]
    ws.row_dimensions[2].height = GROUP_ROW_HEIGHT

    # Ligne 3 : headers
    for col_idx, header in enumerate(HEADERS, start=1):
        cell = ws.cell(row=3, column=col_idx, value=header)
        cell.fill = styles["dark_fill"]
        cell.font = styles["font_white_bold"]
        cell.alignment = styles["align_center"]
        cell.border = styles["border"]
    ws.row_dimensions[3].height = HEADER_ROW_HEIGHT


def create_data_rows(ws: Worksheet, fees_data: List[Dict], styles: Dict[str, object]) -> None:
    for i, row in enumerate(fees_data):
        r = DATA_START_ROW + i
        for col_idx, key in enumerate(KEYS, start=1):
            value = row.get(key)
            cell = ws.cell(row=r, column=col_idx, value=value)
            cell.font = styles["font_black"]
            cell.border = styles["border"]
            cell.alignment = (
                styles["align_left"] if col_idx <= len(GROUPS[0]) else styles["align_center"]
            )
            if col_idx in EDITABLE_COLUMNS:
                cell.fill = styles["edit_fill"]
                if col_idx in NUMERIC_EDITABLE_COLUMNS:
                    cell.number_format = "0.00"


def create_data_validation(ws: Worksheet, fees_data: List[Dict]) -> None:
    """
    Validation sur les colonnes numériques éditables uniquement :
      - valeur vide autorisée
      - sinon : nombre réel >= 0
      - accepte décimales avec '.' ou ','
    Les colonnes texte éditables (Basis of Calculation, Calculation
    Frequency, Payment Frequency, Paid To) n'ont pas de validation
    stricte — l'utilisateur peut y saisir un libellé libre.
    """
    n_rows = max(len(fees_data or []), 1)
    end_row = DATA_START_ROW + n_rows - 1

    def make_formula(anchor_cell: str) -> str:
        return (
            "OR("
            f'{anchor_cell}="",'
            f'IFERROR(VALUE(SUBSTITUTE({anchor_cell},".",","))>=0,FALSE),'
            f'IFERROR(VALUE(SUBSTITUTE({anchor_cell},",","."))>=0,FALSE)'
            ")"
        )

    for col_idx in NUMERIC_EDITABLE_COLUMNS:
        col_letter = get_column_letter(col_idx)
        anchor = f"{col_letter}{DATA_START_ROW}"
        dv = DataValidation(
            type="custom",
            formula1=make_formula(anchor),
            allow_blank=True,
            showErrorMessage=True,
            errorStyle="stop",
            errorTitle=DATA_VALIDATION_ERROR_TITLE,
            error=DATA_VALIDATION_ERROR_MESSAGE,
        )
        ws.add_data_validation(dv)
        dv.add(f"{col_letter}{DATA_START_ROW}:{col_letter}{end_row}")


def apply_protection(ws: Worksheet) -> None:
    # Étape 1 : déverrouille TOUTES les cellules d'abord
    for row in ws.iter_rows(min_row=1, max_row=ws.max_row, min_col=1, max_col=TOTAL_COLUMNS):
        for cell in row:
            cell.protection = Protection(locked=False)

    # Étape 2 : verrouille uniquement ce qui ne doit pas être modifié
    for row_idx in range(1, ws.max_row + 1):
        for col_idx in range(1, TOTAL_COLUMNS + 1):
            cell = ws.cell(row=row_idx, column=col_idx)
            if row_idx >= DATA_START_ROW and col_idx in EDITABLE_COLUMNS:
                cell.protection = Protection(locked=False)
            else:
                cell.protection = Protection(locked=True)

    sheet_protection = SheetProtection()
    sheet_protection.sheet = True
    sheet_protection.objects = False
    sheet_protection.scenarios = False
    sheet_protection.formatCells = False
    sheet_protection.formatColumns = False
    sheet_protection.formatRows = False
    sheet_protection.insertColumns = False
    sheet_protection.insertRows = False
    sheet_protection.insertHyperlinks = False
    sheet_protection.deleteColumns = False
    sheet_protection.deleteRows = False
    sheet_protection.selectLockedCells = False
    sheet_protection.selectUnlockedCells = False
    sheet_protection.sort = False
    sheet_protection.autoFilter = False
    sheet_protection.pivotTables = False
    ws.protection = sheet_protection


def hide_technical_colums(ws: Worksheet) -> None:
    """Cache la colonne technique "Cosmos ID" — elle ne sert qu'au
    re-fetch à l'upload, jamais affichée ni éditée par l'utilisateur."""
    col_letter = get_column_letter(COSMOS_ID_COLUMN_INDEX)
    ws.column_dimensions[col_letter].hidden = True


def create_fees_template_workbook(fees_data: List[Dict]) -> Workbook:
    wb = openpyxl.Workbook()
    ws: Worksheet = wb.active
    ws.title = SHEET_NAME

    styles = create_styles()

    create_header_rows(ws, styles)
    create_data_rows(ws, fees_data, styles)
    create_data_validation(ws, fees_data)
    apply_protection(ws)
    hide_technical_colums(ws)

    ws.freeze_panes = f"A{DATA_START_ROW}"

    for col_idx, w in COL_WIDTHS.items():
        ws.column_dimensions[get_column_letter(col_idx)].width = w

    return wb
