"""
Mapping entre les champs bruts de product_fee et les "type" de la table
own_26967_plmsmartgps.field_value.

Types CONFIRMÉS en base (vérifiés le 22/07 avec SELECT DISTINCT type
FROM field_value) :
  - BASIS_OF_CALCULATION
  - FEE_CALCULATION_FREQUENCY
  - PAYMENT_FREQUENECY   <-- faute de frappe réelle en DB, reproduite telle quelle
  - FEES_PAID_TO

Champs du modèle ProductFee CONFIRMÉS (vérifiés dans src/models/product_fee.py) :
  - calc_frq_cd
  - pmt_frq_cd
  - basis_calc_cd
  - fees_paid_cd   <-- confirmé, PAS "fee_paid_lbl" comme supposé initialement
"""

FIELD_CALC_FRQ = "calc_frq_cd"
FIELD_PMT_FRQ = "pmt_frq_cd"
FIELD_BASIS_CALC = "basis_calc_cd"
FIELD_PAID_TO = "fees_paid_cd"

FEE_CALCULATION_FREQUENCY_TYPE = "FEE_CALCULATION_FREQUENCY"
BASIS_OF_CALCULATION_TYPE = "BASIS_OF_CALCULATION"
PAYMENT_FREQUENECY_TYPE = "PAYMENT_FREQUENECY"  # faute de frappe confirmée en DB
FEES_PAID_TO_TYPE = "FEES_PAID_TO"

# Mapping {nom du champ brut ProductFee: type field_value correspondant}
# Les champs absents de ce dict ne sont pas traduits (laissés tels quels).
FIELD_TO_FIELD_VALUE_TYPE = {
    FIELD_CALC_FRQ: FEE_CALCULATION_FREQUENCY_TYPE,
    FIELD_PMT_FRQ: PAYMENT_FREQUENECY_TYPE,
    FIELD_BASIS_CALC: BASIS_OF_CALCULATION_TYPE,
    FIELD_PAID_TO: FEES_PAID_TO_TYPE,
}
