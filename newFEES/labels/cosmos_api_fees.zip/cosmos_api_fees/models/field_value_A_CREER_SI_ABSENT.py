# -----------------------------------------------------------------------------
# À AJOUTER dans src/models/ SEULEMENT SI le modèle FieldValue n'existe pas
# déjà. Vérifie d'abord : grep -r "class FieldValue" src/models/
# -----------------------------------------------------------------------------

from db import db


class FieldValue(db.Model):
    __tablename__ = "field_value"
    __table_args__ = {"schema": "own_26967_plmsmartgps"}  # adapte le schéma si besoin

    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(100))
    type = db.Column(db.String(100))
    label_fr = db.Column(db.String(500))
    label_en = db.Column(db.String(500))
    is_active = db.Column(db.Boolean)
