# -----------------------------------------------------------------------------
# À AJOUTER dans la classe ExportQueryRepository EXISTANTE
# (src/repositories/export_query_repository.py), à côté de single_export
# et subfund_export. Ne remplace rien d'existant : nouvelle méthode.
#
# Ajoute ces imports en haut de export_query_repository.py :
#   from constants.field_value_types_config import FIELD_TO_FIELD_VALUE_TYPE
#   from services.field_value_cache import get_cached_labels_map
#
# Vérifie aussi que ProductFee est déjà importé (c'est le cas normalement,
# vu que single_export/subfund_export l'utilisent déjà via aliased(ProductFee)).
# -----------------------------------------------------------------------------

    @staticmethod
    def get_raw_fees(sha_cds: list[str]) -> list[dict]:
        """
        Fetch brut : UNE SEULE requête product_fee, filtrée sur sha_cd.
        Le classement par type de fee se fait ensuite en Python
        (FeeExportService.build_fee_columns), piloté par FEE_GROUPS —
        pas de jointure répétée sur product_fee.

        Les codes basis_calc_cd / calc_frq_cd / pmt_frq_cd / fees_paid_cd
        sont traduits en labels via UNE SEULE requête supplémentaire sur
        field_value (mise en cache, cf. field_value_cache.py) — donc au
        pire 2 requêtes DB au total pour tout l'endpoint, peu importe le
        nombre de lignes ou de types de fees.

        Ne touche pas aux jointures ADL in/out existantes dans
        single_export / subfund_export : ADL continue d'être géré tel quel.
        """
        if not sha_cds:
            return []

        rows = (
            db.session.query(ProductFee)
            .filter(ProductFee.sha_cd.in_(sha_cds))
            .all()
        )

        types_needed = list(set(FIELD_TO_FIELD_VALUE_TYPE.values()))
        labels_map = get_cached_labels_map(types_needed)

        def _translate(field_name: str, code):
            if code is None:
                return None
            type_name = FIELD_TO_FIELD_VALUE_TYPE.get(field_name)
            if not type_name:
                return code
            # fallback sur le code brut si le label est introuvable,
            # pour ne jamais perdre d'info silencieusement
            return labels_map.get(type_name, {}).get(code, code)

        return [
            {
                "sha_cd": r.sha_cd,
                "fees_typ_cd": r.fees_typ_cd,
                "fees_subtype_cd": r.fees_subtype_cd,
                "fees_lvl_cd": r.fees_lvl_cd,
                "acq_or_not_acq_fees_cd": r.acq_or_not_acq_fees_cd,
                "specific_fees_cgy_cd": r.specific_fees_cgy_cd,
                "fees_pctg": r.fees_pctg,
                "basis_calc_cd": _translate("basis_calc_cd", r.basis_calc_cd),
                "calc_frq_cd": _translate("calc_frq_cd", r.calc_frq_cd),
                "pmt_frq_cd": _translate("pmt_frq_cd", r.pmt_frq_cd),
                "fees_paid_cd": _translate("fees_paid_cd", r.fees_paid_cd),
            }
            for r in rows
        ]
