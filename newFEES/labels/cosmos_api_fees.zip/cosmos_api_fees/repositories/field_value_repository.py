"""
Repository dédié à la table own_26967_plmsmartgps.field_value.

get_labels_map(types) fait UNE SEULE requête pour récupérer tous les
labels de tous les types demandés, peu importe le nombre de types.
"""

from db import db
from models import FieldValue  # vérifie que ce modèle existe déjà (probable)


class FieldValueRepository:

    @staticmethod
    def get_labels_map(types: list[str]) -> dict[str, dict[str, str]]:
        """
        types : liste des valeurs de la colonne "type" à charger

        Retourne : {type: {code: label_en}}
        """
        if not types:
            return {}

        rows = (
            db.session.query(
                FieldValue.type, FieldValue.code, FieldValue.label_en
            )
            .filter(FieldValue.type.in_(types))
            .all()
        )

        result: dict[str, dict[str, str]] = {}
        for type_, code, label_en in rows:
            result.setdefault(type_, {})[code] = label_en
        return result
