from flask import Blueprint
from flask_restful import Api

from resources.retrieve_fees_data import RetrieveFeesDataResource

RETRIEVE_FEES_DATA_BLUEPRINT = Blueprint("retrieve_fees_data", __name__)

Api(RETRIEVE_FEES_DATA_BLUEPRINT).add_resource(
    RetrieveFeesDataResource, "/retrieve_fees_data", endpoint="retrieve_fees_data"
)

# À enregistrer dans app.py, EXACTEMENT comme RETRIEVE_ADL_FEES_DATA_BLUEPRINT
# (même pattern d'enregistrement, avec ou sans url_prefix selon ce que fait
# déjà l'ADL — vérifie dans app.py comment il est enregistré et copie le
# même style pour éviter les surprises d'URL) :
#
#   from routes.retrieve_fees_data import RETRIEVE_FEES_DATA_BLUEPRINT
#   app.register_blueprint(RETRIEVE_FEES_DATA_BLUEPRINT)  # ou avec url_prefix, à aligner sur ADL
