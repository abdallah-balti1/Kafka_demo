"""
Cache en mémoire (process-local) pour les labels de field_value.

Ces tables de référence changent rarement — pas besoin de les requêter
à chaque appel d'endpoint. Un cache avec TTL évite une requête DB par
appel tout en restant à jour si les labels changent.

Limite connue : ce cache est en mémoire du process Flask. Avec plusieurs
workers (gunicorn multi-process), chaque worker a son propre cache —
acceptable ici, à garder en tête si besoin d'un cache partagé (Redis).
"""

import threading
import time

from repositories.field_value_repository import FieldValueRepository

_CACHE: dict[str, dict[str, str]] = {}
_CACHE_TIMESTAMP: float = 0.0
_CACHE_TTL_SECONDS = 3600  # 1h — ajuste selon la fréquence de changement réelle
_LOCK = threading.Lock()


def get_cached_labels_map(types: list[str]) -> dict[str, dict[str, str]]:
    """
    Retourne {type: {code: label_en}} pour les types demandés.
    Recharge depuis la DB seulement si le cache est vide, expiré, ou
    s'il manque un type demandé.
    """
    global _CACHE, _CACHE_TIMESTAMP

    now = time.time()
    cache_expired = (now - _CACHE_TIMESTAMP) > _CACHE_TTL_SECONDS
    missing_types = [t for t in types if t not in _CACHE]

    if not _CACHE or cache_expired or missing_types:
        with _LOCK:
            now = time.time()
            cache_expired = (now - _CACHE_TIMESTAMP) > _CACHE_TTL_SECONDS
            missing_types = [t for t in types if t not in _CACHE]
            if not _CACHE or cache_expired or missing_types:
                _CACHE = FieldValueRepository.get_labels_map(types)
                _CACHE_TIMESTAMP = now

    return _CACHE


def clear_cache() -> None:
    """Utile pour les tests unitaires, ou pour forcer un refresh manuel."""
    global _CACHE, _CACHE_TIMESTAMP
    with _LOCK:
        _CACHE = {}
        _CACHE_TIMESTAMP = 0.0
