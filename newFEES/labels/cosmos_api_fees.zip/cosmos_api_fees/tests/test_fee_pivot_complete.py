"""
Test unitaire de bout en bout de la logique pure Python (pivot +
traduction), SANS connexion DB.

Lancer avec :
    python tests/test_fee_pivot_complete.py
"""

import sys
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import field_value_cache  # noqa: E402
from services.fee_export_service import FeeExportService  # noqa: E402

FAKE_FIELD_VALUE_RESPONSE = {
    "FEE_CALCULATION_FREQUENCY": {"D": "Daily", "M": "Monthly"},
    "BASIS_OF_CALCULATION": {"1": "Net Asset Value"},
    "PAYMENT_FREQUENECY": {"M": "Monthly"},
    "FEES_PAID_TO": {"1": "Management Company"},
}


def _translate(field_name, code, field_to_type, labels_map):
    if code is None:
        return None
    type_name = field_to_type.get(field_name)
    if not type_name:
        return code
    return labels_map.get(type_name, {}).get(code, code)


def test_pivot_with_translated_labels():
    """
    Simule get_raw_fees (avec traduction) + build_fee_columns, pour un
    fee de type Management MAX, et vérifie que le résultat final contient
    bien les labels traduits, pas les codes bruts.
    """
    field_value_cache.clear_cache()

    with patch(
        "services.field_value_cache.FieldValueRepository.get_labels_map",
        return_value=FAKE_FIELD_VALUE_RESPONSE,
    ):
        from constants.field_value_types_config import FIELD_TO_FIELD_VALUE_TYPE

        labels_map = field_value_cache.get_cached_labels_map(
            list(set(FIELD_TO_FIELD_VALUE_TYPE.values()))
        )

        # Simule une ligne brute product_fee (Management MAX)
        raw_row = {
            "sha_cd": "41455",
            "fees_typ_cd": "2",
            "fees_subtype_cd": "1",  # MANAGEMENT_SUBTYPE
            "fees_lvl_cd": "MAX",
            "acq_or_not_acq_fees_cd": None,
            "specific_fees_cgy_cd": None,
            "fees_pctg": "0.4",
            "basis_calc_cd": _translate("basis_calc_cd", "1", FIELD_TO_FIELD_VALUE_TYPE, labels_map),
            "calc_frq_cd": _translate("calc_frq_cd", "D", FIELD_TO_FIELD_VALUE_TYPE, labels_map),
            "pmt_frq_cd": _translate("pmt_frq_cd", "M", FIELD_TO_FIELD_VALUE_TYPE, labels_map),
            "fees_paid_cd": _translate("fees_paid_cd", "1", FIELD_TO_FIELD_VALUE_TYPE, labels_map),
        }

        result = FeeExportService.build_fee_columns([raw_row])

        assert result["41455"]["Max Management fees Rate"] == "0.4"
        assert result["41455"]["Max Management fees Basis of Calculation"] == "Net Asset Value"
        assert result["41455"]["Max Management fees Calculation Frequency"] == "Daily"
        assert result["41455"]["Max Management fees Payment Frequency"] == "Monthly"

    print("✅ test_pivot_with_translated_labels OK")


def test_missing_fee_returns_none():
    """Un sha_cd sans aucune ligne matchée pour un groupe donné doit
    renvoyer None pour ses colonnes, pas planter."""
    raw_row = {
        "sha_cd": "99999",
        "fees_typ_cd": "2",
        "fees_subtype_cd": "3",  # Distribution, pas Management
        "fees_lvl_cd": "MAX",
        "acq_or_not_acq_fees_cd": None,
        "specific_fees_cgy_cd": None,
        "fees_pctg": "0.1",
        "basis_calc_cd": None,
        "calc_frq_cd": None,
        "pmt_frq_cd": None,
        "fees_paid_cd": None,
    }
    result = FeeExportService.build_fee_columns([raw_row])
    assert result["99999"]["Max Management fees Rate"] is None
    assert result["99999"]["Max Distribution fees Rate"] == "0.1"
    print("✅ test_missing_fee_returns_none OK")


if __name__ == "__main__":
    test_pivot_with_translated_labels()
    test_missing_fee_returns_none()
    print("\n🎉 Tous les tests passent.")
