"""
Mapping entre les champs bruts de product_fee et les "type" de la table
own_26967_plmsmartgps.field_value, pour savoir quelle table de labels
appliquer à quel champ.

⚠️ À CONFIRMER en base avant mise en prod :
  - "FEE_CALCULATION_FREQUENCY" est confirmé (vu dans ta capture) pour
    calc_frq_cd
  - pmt_frq_cd utilise probablement le même type (les fréquences de
    paiement et de calcul partagent souvent les mêmes valeurs D/M/Y/...),
    mais vérifie qu'il n'existe pas un type "FEE_PAYMENT_FREQUENCY" séparé
  - basis_calc_cd : le nom exact du type est à vérifier, "FEE_BASIS_CALCULATION"
    est un nom probable mais pas confirmé — fais un
    SELECT DISTINCT type FROM field_value pour lister tous les types
    disponibles et repérer le bon nom
"""

FIELD_CALC_FRQ = "calc_frq_cd"
FIELD_PMT_FRQ = "pmt_frq_cd"
FIELD_BASIS_CALC = "basis_calc_cd"

FEE_CALCULATION_FREQUENCY_TYPE = "FEE_CALCULATION_FREQUENCY"
FEE_BASIS_CALCULATION_TYPE = "FEE_BASIS_CALCULATION"  # ⚠️ nom à confirmer en DB

# Mapping {nom du champ brut: type field_value correspondant}
# Les champs absents de ce dict ne sont pas traduits (laissés tels quels).
FIELD_TO_FIELD_VALUE_TYPE = {
    FIELD_CALC_FRQ: FEE_CALCULATION_FREQUENCY_TYPE,
    FIELD_PMT_FRQ: FEE_CALCULATION_FREQUENCY_TYPE,  # ⚠️ à confirmer, cf. docstring
    FIELD_BASIS_CALC: FEE_BASIS_CALCULATION_TYPE,  # ⚠️ à confirmer, cf. docstring
}
