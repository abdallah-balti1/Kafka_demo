# -----------------------------------------------------------------------------
# REMPLACE la méthode get_raw_fees existante dans ExportQueryRepository
# (celle qu'on avait ajoutée précédemment) par CETTE version.
#
# Différence avec la version précédente : les champs basis_calc_cd,
# calc_frq_cd et pmt_frq_cd contiennent maintenant directement le label_en
# (ex: "Monthly") au lieu du code brut (ex: "M"). La traduction se fait
# ICI, une seule fois, AVANT le pivot — FeeExportService et FEE_GROUPS
# n'ont RIEN à changer, ils continuent de lire les mêmes noms de champs.
#
# Ajoute ces imports en haut de export_query_repository.py :
#   from constants.field_value_types_config import FIELD_TO_FIELD_VALUE_TYPE
#   from services.field_value_cache import get_cached_labels_map
# -----------------------------------------------------------------------------

    @staticmethod
    def get_raw_fees(sha_cds: list[str]) -> list[dict]:
        """
        Fetch brut : UNE SEULE requête product_fee + labels déjà traduits.

        Les codes basis_calc_cd / calc_frq_cd / pmt_frq_cd sont remplacés
        par leur label_en (via un cache en mémoire, lui-même chargé par
        UNE SEULE requête sur field_value, quel que soit le nombre de
        types ou le nombre de lignes product_fee à traduire).

        Ne touche pas aux jointures ADL in/out existantes dans
        single_export / subfund_export : ADL continue d'être géré tel quel.
        """
        if not sha_cds:
            return []

        rows = (
            db.session.query(ProductFee)
            .filter(ProductFee.sha_cd.in_(sha_cds))
            .all()
        )

        # 1 seule requête sur field_value pour tous les types nécessaires,
        # quel que soit le nombre de lignes product_fee à traduire ensuite
        types_needed = list(set(FIELD_TO_FIELD_VALUE_TYPE.values()))
        labels_map = get_cached_labels_map(types_needed)

        def _translate(field_name: str, code):
            if code is None:
                return None
            type_name = FIELD_TO_FIELD_VALUE_TYPE.get(field_name)
            if not type_name:
                return code  # champ non concerné par une traduction
            # fallback sur le code brut si le label n'est pas trouvé,
            # pour ne jamais perdre d'info silencieusement
            return labels_map.get(type_name, {}).get(code, code)

        return [
            {
                "sha_cd": r.sha_cd,
                "fees_typ_cd": r.fees_typ_cd,
                "fees_subtype_cd": r.fees_subtype_cd,
                "fees_lvl_cd": r.fees_lvl_cd,
                "acq_or_not_acq_fees_cd": r.acq_or_not_acq_fees_cd,
                "specific_fees_cgy_cd": r.specific_fees_cgy_cd,
                "fees_pctg": r.fees_pctg,
                "basis_calc_cd": _translate("basis_calc_cd", r.basis_calc_cd),
                "calc_frq_cd": _translate("calc_frq_cd", r.calc_frq_cd),
                "pmt_frq_cd": _translate("pmt_frq_cd", r.pmt_frq_cd),
                "fee_paid_lbl": getattr(r, "fee_paid_lbl", None),
            }
            for r in rows
        ]
