"""
Repository dédié à la table own_26967_plmsmartgps.field_value.

get_labels_map(types) fait UNE SEULE requête pour récupérer tous les
labels de tous les types demandés, peu importe le nombre de types —
pas une requête par type et surtout pas une requête par ligne de donnée.
"""

from db import db

# Adapte cet import au nom réel du modèle SQLAlchemy pour field_value,
# s'il n'existe pas encore il faut le créer (voir modele_field_value_A_CREER.py
# fourni dans ce package si besoin).
from models import FieldValue


class FieldValueRepository:

    @staticmethod
    def get_labels_map(types: list[str]) -> dict[str, dict[str, str]]:
        """
        types : liste des valeurs de la colonne "type" à charger
                (ex: ["FEE_CALCULATION_FREQUENCY", "FEE_BASIS_CALCULATION"])

        Retourne : {type: {code: label_en}}
        Une seule requête SQL, quel que soit le nombre de types demandés.
        """
        if not types:
            return {}

        rows = (
            db.session.query(
                FieldValue.type, FieldValue.code, FieldValue.label_en
            )
            .filter(FieldValue.type.in_(types))
            .all()
        )

        result: dict[str, dict[str, str]] = {}
        for type_, code, label_en in rows:
            result.setdefault(type_, {})[code] = label_en
        return result
