# -----------------------------------------------------------------------------
# À AJOUTER dans src/models/ (ou dans le fichier où sont déjà déclarés
# Share, Subfund, Umbrella, ProductFee...) SEULEMENT SI le modèle FieldValue
# n'existe pas déjà. Vérifie d'abord avec :
#   grep -r "class FieldValue" src/models/
#
# Si le modèle existe déjà (probable, vu que la table est déjà en base et
# utilisée ailleurs dans l'appli), ignore ce fichier et adapte simplement
# l'import dans field_value_repository.py.
# -----------------------------------------------------------------------------

from db import db


class FieldValue(db.Model):
    __tablename__ = "field_value"
    __table_args__ = {"schema": "own_26967_plmsmartgps"}  # adapte le schéma si besoin

    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(100))
    type = db.Column(db.String(100))
    label_fr = db.Column(db.String(500))
    label_en = db.Column(db.String(500))
    is_active = db.Column(db.Boolean)
