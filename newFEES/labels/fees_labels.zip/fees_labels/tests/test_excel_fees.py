"""
Script de test manuel : appelle l'endpoint /retrieve_fees_data en local,
puis génère le fichier Excel avec FeeExcelGenerator.

AUCUN CHANGEMENT nécessaire dans ce script suite à l'ajout de la
traduction des labels — la traduction se fait dans get_raw_fees, en
amont du pivot. FeeExportService et FeeExcelGenerator continuent de
lire les mêmes noms de champs ("Basis of Calculation", "Calculation
Frequency"...), qui contiennent maintenant directement "Monthly" au
lieu de "M".

Usage :
    python test_excel_fees.py 42735

Prérequis :
    - Le serveur Flask doit tourner en local
    - pip install requests
    - Lancer depuis la racine du projet flowr-cosmos-api
"""

import sys
from pathlib import Path

import requests

# Ajuste si ce script n'est pas à la racine du projet
sys.path.insert(0, str(Path(__file__).resolve().parent))

from services.fee_excel_generator import FeeExcelGenerator  # noqa: E402

BASE_URL = "http://127.0.0.1:5001"
ENDPOINT = "/smartgps/retrieve_fees_data"  # adapte selon ton prefix réel

HEADERS = {
    "Content-Type": "application/json",
    "Authorization": "Bearer <COLLE_TON_TOKEN_ICI>",
}

# Ignore les proxies système — utile en environnement corporate où
# http_proxy/https_proxy sont configurés pour le trafic externe et
# cassent les appels vers 127.0.0.1 en local.
PROXIES = {"http": None, "https": None}


def fetch_fees_data(prod_cd_list: list[str]) -> dict:
    response = requests.post(
        f"{BASE_URL}{ENDPOINT}",
        json={"prod_cd_list": prod_cd_list},
        headers=HEADERS,
        timeout=30,
        proxies=PROXIES,
    )
    response.raise_for_status()
    return response.json()


def main():
    prod_cd_list = sys.argv[1:] or ["42735"]

    print(f"→ Appel de {BASE_URL}{ENDPOINT} avec prod_cd_list={prod_cd_list}")
    data = fetch_fees_data(prod_cd_list)

    all_rows = data.get("SIN", []) + data.get("SUB", [])
    if not all_rows:
        print("⚠️  Aucune ligne retournée par l'endpoint, rien à générer.")
        return

    print(f"→ {len(all_rows)} ligne(s) récupérée(s), génération du fichier Excel...")

    # Vérif rapide que les labels sont bien traduits (pas juste des codes)
    sample = all_rows[0]
    for col in ("Max Management fees Basis of Calculation", "Max Management fees Calculation Frequency"):
        if col in sample:
            print(f"   {col}: {sample[col]!r}")

    excel_buffer = FeeExcelGenerator.generate(all_rows)

    output_path = Path("test_fees_output.xlsx")
    output_path.write_bytes(excel_buffer.read())

    print(f"✅ Fichier généré : {output_path.resolve()}")


if __name__ == "__main__":
    main()
