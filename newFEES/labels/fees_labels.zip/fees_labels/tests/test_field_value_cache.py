"""
Test unitaire de la logique de traduction, SANS connexion DB — on mocke
FieldValueRepository.get_labels_map pour vérifier que :
  1. Une seule requête est faite même si on traduit plusieurs lignes
  2. Le mapping code -> label_en fonctionne
  3. Le fallback sur le code brut fonctionne si le label est introuvable

Lancer avec :
    python -m pytest tests/test_field_value_cache.py -v
ou simplement :
    python tests/test_field_value_cache.py
"""

import sys
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import field_value_cache  # noqa: E402


FAKE_DB_RESPONSE = {
    "FEE_CALCULATION_FREQUENCY": {
        "D": "Daily",
        "M": "Monthly",
        "Y": "Yearly",
    },
    "FEE_BASIS_CALCULATION": {
        "1": "Net Asset Value",
    },
}


def test_single_query_for_multiple_lookups():
    """Vérifie qu'un seul appel DB est fait même si on traduit plusieurs codes."""
    field_value_cache.clear_cache()

    with patch(
        "services.field_value_cache.FieldValueRepository.get_labels_map",
        return_value=FAKE_DB_RESPONSE,
    ) as mock_get_labels:
        # 3 appels au cache, mais un seul doit toucher la DB
        field_value_cache.get_cached_labels_map(
            ["FEE_CALCULATION_FREQUENCY", "FEE_BASIS_CALCULATION"]
        )
        field_value_cache.get_cached_labels_map(
            ["FEE_CALCULATION_FREQUENCY", "FEE_BASIS_CALCULATION"]
        )
        field_value_cache.get_cached_labels_map(
            ["FEE_CALCULATION_FREQUENCY", "FEE_BASIS_CALCULATION"]
        )

        assert mock_get_labels.call_count == 1, (
            f"Attendu 1 appel DB, obtenu {mock_get_labels.call_count} — "
            "le cache ne fonctionne pas comme prévu"
        )
    print("✅ test_single_query_for_multiple_lookups OK")


def test_translation_mapping():
    """Vérifie que le mapping code -> label_en est correct."""
    field_value_cache.clear_cache()

    with patch(
        "services.field_value_cache.FieldValueRepository.get_labels_map",
        return_value=FAKE_DB_RESPONSE,
    ):
        labels_map = field_value_cache.get_cached_labels_map(
            ["FEE_CALCULATION_FREQUENCY"]
        )
        assert labels_map["FEE_CALCULATION_FREQUENCY"]["M"] == "Monthly"
        assert labels_map["FEE_CALCULATION_FREQUENCY"]["D"] == "Daily"
    print("✅ test_translation_mapping OK")


def test_fallback_on_unknown_code():
    """Vérifie qu'un code inconnu ne casse rien (fallback géré côté appelant)."""
    field_value_cache.clear_cache()

    with patch(
        "services.field_value_cache.FieldValueRepository.get_labels_map",
        return_value=FAKE_DB_RESPONSE,
    ):
        labels_map = field_value_cache.get_cached_labels_map(
            ["FEE_CALCULATION_FREQUENCY"]
        )
        # Le code "X" n'existe pas dans FAKE_DB_RESPONSE : à l'appelant
        # (get_raw_fees._translate) de faire le fallback via .get(code, code)
        result = labels_map["FEE_CALCULATION_FREQUENCY"].get("X", "X")
        assert result == "X"
    print("✅ test_fallback_on_unknown_code OK")


if __name__ == "__main__":
    test_single_query_for_multiple_lookups()
    test_translation_mapping()
    test_fallback_on_unknown_code()
    print("\n🎉 Tous les tests passent.")
