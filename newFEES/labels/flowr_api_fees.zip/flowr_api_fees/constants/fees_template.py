"""
Config du template Excel "Fees" généralisé (flowr_api).

Reprend le pattern de constants/specific_fees.py (ADL in/out, déjà en
prod) : HEADERS, GROUPS, COL_WIDTHS dérivés d'une spec déclarative.

⚠️ IMPORTANT : les clés JSON utilisées ci-dessous (2e élément de chaque
tuple dans FEE_SECTIONS) doivent rester synchronisées avec les clés
produites côté cosmos_api (constants/fee_groups_config.py +
constants/excel_layout_config.py). Si un nom de colonne change d'un
côté, il doit changer ici aussi — ce sont deux repos séparés, pas de
partage de code possible, donc cette duplication est un risque connu
à surveiller (idéalement, en tester la cohérence via un test
d'intégration qui appelle réellement l'endpoint cosmos_api et vérifie
que toutes les clés attendues sont présentes).

Stratégie de diff retenue : PAS de duplication de chaque champ en
colonne cachée. Une seule colonne technique cachée par ligne
("Cosmos ID" = sha_cd) permet, à l'upload, de rappeler cosmos_api pour
chaque sha_cd et comparer les valeurs fraîches à celles du fichier —
la comparaison se fait au moment de l'upload, pas via des colonnes
figées au téléchargement.
"""

from typing import Dict, List, Tuple

SHEET_NAME = "Fees Review"
TITLE_TEXT = "Fees Update"

# --- Styles (mêmes valeurs que specific_fees.py pour rester cohérent visuellement) ---
FONT_NAME = "Arial"
FONT_SIZE = 8
BORDER_COLOR = "000000"
BLACK_FILL_COLOR = "000000"
DARK_FILL_COLOR = "4472C4"
EDIT_FILL_COLOR = "FFF2CC"

TITLE_ROW_HEIGHT = 20
GROUP_ROW_HEIGHT = 18
HEADER_ROW_HEIGHT = 30

DATA_VALIDATION_ERROR_TITLE = "Valeur invalide"
DATA_VALIDATION_ERROR_MESSAGE = (
    "Merci de saisir un nombre réel positif (ou de laisser la cellule vide)."
)

# Ligne 1 = titre, ligne 2 = groupes, ligne 3 = headers, ligne 4+ = données
DATA_START_ROW = 4

# --- Colonnes d'identification (non éditables) ---
# "Cosmos ID" (sha_cd) est une colonne TECHNIQUE CACHÉE : sert uniquement
# à identifier la ligne pour le re-fetch à l'upload, jamais affichée/éditée.
COSMOS_ID_KEY = "sha_cd"

BASE_COLUMNS: List[Tuple[str, str]] = [
    ("Cosmos ID", COSMOS_ID_KEY),  # colonne technique, cachée
    ("Umbrella name", "umb_name_lbl"),
    ("Sub-fund name", "sbf_name"),
    ("Sub-fund ALADDIN code", "prod_cd_valu"),
    ("Sub-fund MFFA code", "prod_cd_mffa"),
    ("Sub-fund status", "sbf_stat_lbl"),
    ("Share name", "sha_name"),
    ("ISIN code", "isin_cd"),
    ("Share status", "sha_stat_lbl"),
    ("Nav valuation date", "nav_valuation_date"),
]

# --- Colonnes de fees, TOUTES éditables, groupées par section ---
# Les clés doivent matcher exactement celles produites par cosmos_api.
FEE_SECTIONS: List[Dict] = [
    {
        "title": "Subscription/Redemption/Conversion fees",
        "columns": [
            ("Subscription Acquired MAX Rate", "Subscription Acquired MAX Rate"),
            ("Subscription Non Acquired MAX Rate", "Subscription Non Acquired MAX Rate"),
            ("Redemption Acquired MAX Rate", "Redemption Acquired MAX Rate"),
            ("Redemption Non Acquired MAX Rate", "Redemption Non Acquired MAX Rate"),
            ("Conversion Rate", "Conversion Rate"),
        ],
    },
    {
        "title": "Specific fees - ADL",
        "columns": [
            ("Max ADL In Rate", "max_adl_in_fee"),
            ("ADL In Rate", "adl_in_fee"),
            ("Max ADL Out Rate", "max_adl_out_fee"),
            ("ADL Out Rate", "adl_out_fee"),
        ],
    },
    {
        "title": "Management fees",
        "columns": [
            ("Max Management fees Rate", "Max Management fees Rate"),
            ("Max Management fees Basis of Calculation", "Max Management fees Basis of Calculation"),
            ("Max Management fees Calculation Frequency", "Max Management fees Calculation Frequency"),
            ("Max Management fees Payment Frequency", "Max Management fees Payment Frequency"),
            ("Real Management fees Rate", "Real Management fees Rate"),
            ("Real Management fees Basis of Calculation", "Real Management fees Basis of Calculation"),
            ("Real Management fees Calculation Frequency", "Real Management fees Calculation Frequency"),
            ("Real Management fees Payment Frequency", "Real Management fees Payment Frequency"),
        ],
    },
    {
        "title": "Distribution fees",
        "columns": [
            ("Max Distribution fees Rate", "Max Distribution fees Rate"),
            ("Max Distribution fees Basis of Calculation", "Max Distribution fees Basis of Calculation"),
            ("Max Distribution fees Calculation Frequency", "Max Distribution fees Calculation Frequency"),
            ("Max Distribution fees Payment Frequency", "Max Distribution fees Payment Frequency"),
            ("Real Distribution fees Rate", "Real Distribution fees Rate"),
            ("Real Distribution fees Basis of Calculation", "Real Distribution fees Basis of Calculation"),
            ("Real Distribution fees Calculation Frequency", "Real Distribution fees Calculation Frequency"),
            ("Real Distribution fees Payment Frequency", "Real Distribution fees Payment Frequency"),
        ],
    },
    {
        "title": "Charity fees",
        "columns": [
            ("Max Charity fees Rate", "Max Charity fees Rate"),
            ("Max Charity fees Basis of Calculation", "Max Charity fees Basis of Calculation"),
            ("Max Charity fees Calculation Frequency", "Max Charity fees Calculation Frequency"),
            ("Max Charity fees Payment Frequency", "Max Charity fees Payment Frequency"),
            ("Real Charity fees Rate", "Real Charity fees Rate"),
            ("Real Charity fees Basis of Calculation", "Real Charity fees Basis of Calculation"),
            ("Real Charity fees Calculation Frequency", "Real Charity fees Calculation Frequency"),
            ("Real Charity fees Payment Frequency", "Real Charity fees Payment Frequency"),
        ],
    },
    {
        "title": "Advisory fees",
        "columns": [
            ("Max Advisory fees Rate", "Max Advisory fees Rate"),
            ("Max Advisory fees Basis of Calculation", "Max Advisory fees Basis of Calculation"),
            ("Max Advisory fees Calculation Frequency", "Max Advisory fees Calculation Frequency"),
            ("Max Advisory fees Payment Frequency", "Max Advisory fees Payment Frequency"),
            ("Real Advisory fees Rate", "Real Advisory fees Rate"),
            ("Real Advisory fees Basis of Calculation", "Real Advisory fees Basis of Calculation"),
            ("Real Advisory fees Calculation Frequency", "Real Advisory fees Calculation Frequency"),
            ("Real Advisory fees Payment Frequency", "Real Advisory fees Payment Frequency"),
        ],
    },
    {
        "title": "Specific & External fees",
        "columns": [
            ("Max Other Costs Rate", "Max Other Costs Rate"),
            ("Max Other Costs Basis of Calculation", "Max Other Costs Basis of Calculation"),
            ("Max Other Costs Calculation Frequency", "Max Other Costs Calculation Frequency"),
            ("Max Other Costs Payment Frequency", "Max Other Costs Payment Frequency"),
            ("Max Other Costs Paid To", "Max Other Costs Paid To"),
            ("Real Other Costs Rate", "Real Other Costs Rate"),
            ("Real Other Costs Basis of Calculation", "Real Other Costs Basis of Calculation"),
            ("Real Other Costs Calculation Frequency", "Real Other Costs Calculation Frequency"),
            ("Real Other Costs Payment Frequency", "Real Other Costs Payment Frequency"),
            ("Real Other Costs Paid To", "Real Other Costs Paid To"),
            ("Max Foreign UCIs Tax Rate", "Max Foreign UCIs Tax Rate"),
            ("Max Foreign UCIs Tax Basis of Calculation", "Max Foreign UCIs Tax Basis of Calculation"),
            ("Max Foreign UCIs Tax Calculation Frequency", "Max Foreign UCIs Tax Calculation Frequency"),
            ("Max Foreign UCIs Tax Payment Frequency", "Max Foreign UCIs Tax Payment Frequency"),
            ("Max Foreign UCIs Tax Paid To", "Max Foreign UCIs Tax Paid To"),
            ("Real Foreign UCIs Tax Rate", "Real Foreign UCIs Tax Rate"),
            ("Real Foreign UCIs Tax Basis of Calculation", "Real Foreign UCIs Tax Basis of Calculation"),
            ("Real Foreign UCIs Tax Calculation Frequency", "Real Foreign UCIs Tax Calculation Frequency"),
            ("Real Foreign UCIs Tax Payment Frequency", "Real Foreign UCIs Tax Payment Frequency"),
            ("Real Foreign UCIs Tax Paid To", "Real Foreign UCIs Tax Paid To"),
            ("Max Taxe Abonnement Rate", "Max Taxe Abonnement Rate"),
            ("Max Taxe Abonnement Basis of Calculation", "Max Taxe Abonnement Basis of Calculation"),
            ("Max Taxe Abonnement Calculation Frequency", "Max Taxe Abonnement Calculation Frequency"),
            ("Max Taxe Abonnement Payment Frequency", "Max Taxe Abonnement Payment Frequency"),
            ("Max Taxe Abonnement Paid To", "Max Taxe Abonnement Paid To"),
            ("Real Taxe Abonnement Rate", "Real Taxe Abonnement Rate"),
            ("Real Taxe Abonnement Basis of Calculation", "Real Taxe Abonnement Basis of Calculation"),
            ("Real Taxe Abonnement Calculation Frequency", "Real Taxe Abonnement Calculation Frequency"),
            ("Real Taxe Abonnement Payment Frequency", "Real Taxe Abonnement Payment Frequency"),
            ("Real Taxe Abonnement Paid To", "Real Taxe Abonnement Paid To"),
        ],
    },
]

# -----------------------------------------------------------------------------
# Génération automatique de HEADERS / KEYS / GROUPS / EDITABLE_COLUMNS
# à partir de BASE_COLUMNS + FEE_SECTIONS ci-dessus. Ne pas éditer à la main
# en dessous de cette ligne — modifie BASE_COLUMNS / FEE_SECTIONS à la place.
# -----------------------------------------------------------------------------

HEADERS: List[str] = [label for label, _ in BASE_COLUMNS]
KEYS: List[str] = [key for _, key in BASE_COLUMNS]

# GROUPS : liste de (start_col, end_col, label) pour la ligne 2 (groupes),
# en colonnes 1-based, comme dans specific_fees.py existant.
GROUPS: List[Tuple[int, int, str]] = [(1, len(BASE_COLUMNS), "General Information")]

# EDITABLE_COLUMNS : indices de colonnes (1-based) éditables par l'utilisateur.
# Toutes les colonnes de fees sont éditables, aucune colonne de BASE_COLUMNS
# ne l'est (identification produit) — "Cosmos ID" n'est même pas affichée.
EDITABLE_COLUMNS: List[int] = []

_current_col = len(BASE_COLUMNS) + 1
for section in FEE_SECTIONS:
    section_start = _current_col
    for label, key in section["columns"]:
        HEADERS.append(label)
        KEYS.append(key)
        EDITABLE_COLUMNS.append(_current_col)
        _current_col += 1
    GROUPS.append((section_start, _current_col - 1, section["title"]))

TOTAL_COLUMNS = len(HEADERS)

# Largeurs de colonnes : plus larges pour les colonnes texte d'identification,
# standard pour les colonnes de fees.
COL_WIDTHS: Dict[int, int] = {}
for idx, (label, _) in enumerate(BASE_COLUMNS, start=1):
    COL_WIDTHS[idx] = 12 if label == "Cosmos ID" else 22
for idx in range(len(BASE_COLUMNS) + 1, TOTAL_COLUMNS + 1):
    COL_WIDTHS[idx] = 16

# Index de la colonne "Cosmos ID", pour la cacher explicitement
COSMOS_ID_COLUMN_INDEX = 1
