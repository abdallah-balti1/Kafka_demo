# -----------------------------------------------------------------------------
# À AJOUTER à la fin du fichier EXISTANT : src/constants/export_query_constants.py
# Ne pas écraser le fichier, ce sont des AJOUTS aux constantes déjà présentes
# (MAX_ADL_IN_CATEGORY, ADL_IN_LEVEL, SHA_CD_LABEL, etc. restent inchangées).
# -----------------------------------------------------------------------------

# --- Fees subtype codes (fees_typ_cd = "2", "Direct Fees") ---
MANAGEMENT_SUBTYPE = "1"
ADVISORY_SUBTYPE = "2"
DISTRIBUTION_SUBTYPE = "3"
CHARITY_SUBTYPE = "4"
SPECIFIC_EXTERNAL_SUBTYPE = "5"
PERFORMANCE_SUBTYPE = "6"
SUBSCRIPTION_SUBTYPE = "7"
REDEMPTION_SUBTYPE = "8"
CONVERSION_SUBTYPE = "9"

# --- Specific fees category codes (utilisés sous SPECIFIC_EXTERNAL_SUBTYPE uniquement) ---
TAXE_ABONNEMENT_CATEGORY = "1"
OTHER_COSTS_CATEGORY = "15"
FOREIGN_UCIS_TAX_CATEGORY = "41"
# NB : ADL_IN_CATEGORY = "19" et ADL_OUT_CATEGORY = "27" existent déjà
# dans le fichier existant, ne pas les redéfinir.

# --- Acquired / Not acquired ---
ACQUIRED = "1"
NOT_ACQUIRED = "2"

# --- Levels ---
MAX_LEVEL = "MAX"
REEL_LEVEL = "REEL"
