from context_managers.session_critical_action_manager import SessionCriticalActionManager
from flasgger.utils import swag_from
from flask import request
from flask_restful import Resource

from config import DEV_TEAM_EMAILS
from constants.export_query_constants import SHA_CD_LABEL
from db import db
from repositories.export_query_repository import ExportQueryRepository
from repositories.product import ProductRepository
from services.fee_export_service import FeeExportService
from utils.required_authentication import required_authentication


class RetrieveFeesDataResource(Resource):
    """Renvoie toutes les fees (ADL in/out + Management/Distribution/
    Charity/Advisory/Subscription/Redemption/Conversion/Specific & External)
    pour une liste de produits, en JSON.

    Ce microservice ne fait QUE de la donnée : la génération de l'Excel
    et le téléchargement sont gérés par un autre microservice qui
    consomme cette réponse."""

    @staticmethod
    @required_authentication()
    @swag_from("../../swagger/retrieve_fees_data/POST.yml")
    def post(user):
        data = request.get_json(silent=True) or {}

        prod_cd_list = data.get("prod_cd_list", [])
        if not isinstance(prod_cd_list, list) or not prod_cd_list:
            return {"error": "prod_cd_list is required and must be a non-empty list"}, 400

        prod_cd_list = [str(x).strip() for x in prod_cd_list if str(x).strip()]
        if not prod_cd_list:
            return {"error": "prod_cd_list is empty"}, 400

        with SessionCriticalActionManager("last_file_version", db.session, DEV_TEAM_EMAILS):
            origins = ProductRepository.get_latest_origins(prod_cd_list)

            sin_list = [p for p in prod_cd_list if origins.get(p) == "SIN"]
            sub_list = [p for p in prod_cd_list if origins.get(p) == "SUB"]
            unknown = [p for p in prod_cd_list if origins.get(p) not in ("SIN", "SUB")]

            # 1. Requêtes existantes (métadonnées produit + ADL in/out) — INCHANGÉES
            sin_rows = ExportQueryRepository.single_export(sin_list) if sin_list else []
            sub_rows = ExportQueryRepository.subfund_export(sub_list) if sub_list else []
            all_rows = sin_rows + sub_rows

            # 2. Fetch brut (1 seule requête) + pivot Python pour les autres fees
            sha_cds = [row[SHA_CD_LABEL] for row in all_rows]
            raw_fees = ExportQueryRepository.get_raw_fees(sha_cds)
            fee_columns = FeeExportService.build_fee_columns(raw_fees)

            # 3. Merge : chaque ligne existante est enrichie avec les nouvelles colonnes
            for row in all_rows:
                row.update(fee_columns.get(row[SHA_CD_LABEL], {}))

        return {"SIN": sin_rows, "SUB": sub_rows, "unknown": unknown}, 200
