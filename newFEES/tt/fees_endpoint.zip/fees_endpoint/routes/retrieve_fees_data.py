from flask import Blueprint
from flask_restful import Api

from resources.retrieve_fees_data import RetrieveFeesDataResource

RETRIEVE_FEES_DATA_BLUEPRINT = Blueprint("retrieve_fees_data", __name__)

Api(RETRIEVE_FEES_DATA_BLUEPRINT).add_resource(
    RetrieveFeesDataResource, "/retrieve_fees_data", endpoint="retrieve_fees_data"
)

# À enregistrer comme les autres blueprints, ex. dans app.py :
#   from routes.retrieve_fees_data import RETRIEVE_FEES_DATA_BLUEPRINT
#   app.register_blueprint(RETRIEVE_FEES_DATA_BLUEPRINT, url_prefix="/api")
